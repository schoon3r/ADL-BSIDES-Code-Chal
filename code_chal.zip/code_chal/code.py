# type: ignore
import hashlib, sys

def str_xor(secret, key):    
    new_key = key
    i = 0
    while len(new_key) < len(secret):
        new_key = new_key + key[i]
        i = (i + 1) % len(key)        
    return "".join([chr(ord(secret_c) ^ ord(new_key_c)) for (secret_c,new_key_c) in zip(secret,new_key)])

a_secret = open('flag.txt.enc', 'rb').read()
a_hash = open('hash.bin', 'rb').read()

def b_hash(pw_str):
    pw_bytes = bytearray()
    pw_bytes.extend(pw_str.encode())
    m = hashlib.md5()
    m.update(pw_bytes)
    return m.digest()

if __name__ == "__main__":    
    enter_password = input("Enter Password: ")
    password_hash = b_hash(enter_password)
    
    if( password_hash == a_hash ):
        print("\nCongratulations!")
        decryption = str_xor(a_secret.decode(), enter_password)
        print(decryption)
        sys.exit()
    print("LOL! Try again...")

# Password List
pos_pw_list = [
    "158f", "1655", "d21e", "4966", "ed69", "1010", "dded", "844c", "40ab", "a948", 
    "156c", "ab7f", "4a5f", "e38c", "ba12", "f7fd", "d780", "4f4d", "5ba1", "96c5", 
    "55b9", "8a67", "d32b", "aa7a", "514b", "e4e1", "1230", "cd19", "d6dd", "b01f", 
    "fd2f", "7587", "86c2", "d7b8", "55a2", "b77c", "7ffe", "4420", "e0ee", "d8fb", 
    "d748", "b0fe", "2a37", "a638", "52db", "51b7", "5526", "40ed", "5356", "6ad4",
    "2ddd", "177d", "84ae", "cf88", "97a3", "17ad", "7124", "eff2", "e373", "c974", 
    "7689", "b8b2", "e899", "d042", "47d9", "cca9", "ab2a", "de77", "4654", "9ecb", 
    "ab6e", "bb8e", "b76b", "d661", "63f8", "7095", "567e", "b837", "2b80", "ad4f", 
    "c514", "ffa4", "fc37", "7254", "b48b", "d38b", "a02b", "ec6c", "eacc", "8b70", 
    "b03e", "1b36", "81ff", "7744", "dbe6", "59d9", "fd6a", "5653", "8b95", "d0e5",
    "9d8e", "8c9e", "7b8e", "6a9e", "59ae", "48ae", "37be", "26ce", "15de", "04ee",
    "f7de", "e6ee", "d5fe", "c4ee", "b3ee", "a2ee", "91ee", "80ee", "7fee", "6eee",
    "5dee", "4cee", "3bee", "2aee", "19ee", "08ee", "f9ed", "e8ed", "d7ed", "c6ed",
    "b5ed", "a4ed", "93ed", "82ed", "71ed", "60ed", "4fed", "3eed", "2ded", "1ced",
    "0bed", "faec", "e9ec", "d8ec", "c7ec", "b6ec", "a5ec", "94ec", "83ec", "72ec",
    "61ec", "50ec", "3fec", "2eec", "1dec", "0cec", "fb3c", "ea3c", "d93c", "c83c",
    "b73c", "a63c", "953c", "843c", "733c", "623c", "513c", "403c", "2f3c", "1e3c",
    "0d3c", "fc2c", "eb2c", "da2c", "c92c", "b82c", "a72c", "963c", "853c", "743c",
    "633c", "523c", "413c", "303c", "1f3c", "0e3c", "fd1c", "ec1c", "db1c", "ca1c",
    "b91c", "a81c", "971c", "861c", "751c", "641c", "531c", "421c", "311c", "201c",
    "1e1c", "0d1c", "fc0c", "eb0c", "da0c", "c90c", "b80c", "a70c", "961c", "851c",
    "741c", "631c", "521c", "411c", "301c", "1f1c", "0e1c", "fd0c", "ec0c", "db0c",
    "ca0c", "b90c", "a80c", "970c", "860c", "750c", "640c", "530c", "420c", "310c",
    "200c", "1f0c", "0e0c", "fcfc", "ebfc", "dafc", "c9fc", "b8fc", "a7fc", "96fc",
    "85fc", "74fc", "63fc", "52fc", "41fc", "30fc", "1efc", "0dfc", "fcfb", "ebfb",
    "dafb", "c9fb", "b8fb", "a7fb", "96fb", "85fb", "74fb", "63fb", "52fb", "41fb",
    "30fb", "1efb", "0dfb", "fcfa", "ebfa", "dafa", "c9fa", "b8fa", "a7fa", "96fa",
    "85fa", "74fa", "63fa", "52fa", "41fa", "30fa", "1efa", "0dfa", "fcf9", "ebf9",
    "daf9", "c9f9", "b8f9", "a7f9", "96f9", "85f9", "74f9", "63f9", "52f9", "41f9",
    "30f9", "1ef9", "0df9", "fcf8", "ebf8", "daf8", "c9f8", "b8f8", "a7f8", "96f8",
    "85f8", "74f8", "63f8", "52f8", "41f8", "30f8", "1ef8", "0df8", "fcf7", "ebf7",
    "daf7", "c9f7", "b8f7", "a7f7", "96f7", "85f7", "74f7", "63f7", "52f7", "41f7",
    "30f7", "1ef7", "0df7", "fcf6", "ebf6", "daf6", "c9f6", "b8f6", "a7f6", "96f6",
    "85f6", "74f6", "63f6", "52f6", "41f6", "30f6", "1ef6", "0df6", "fcf5", "ebf5",
    "daf5", "c9f5", "b8f5", "a7f5", "96f5", "85f5", "74f5", "63f5", "77e4", "41f5",
    "30f5", "1ef5", "0df5", "fcf4", "ebf4", "daf4", "c9f4", "b8f4", "a7f4", "96f4",
    "85f4", "74f4", "63f4", "52f4", "41f4", "30f4", "1ef4", "0df4"
]


